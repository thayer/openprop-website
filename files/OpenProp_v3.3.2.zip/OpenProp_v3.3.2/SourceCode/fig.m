function H = fig(H)

if nargin == 1
    
    figure(H); hold on, box on, grid on,
    
else

    H = figure; hold on, box on, grid on,

end